package run;

public @interface BeforeClass {

}
